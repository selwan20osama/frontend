document.getElementById("tel").oninput = function () {
  this.value = this.value.replace(/[^0-9]/g, "");
};
